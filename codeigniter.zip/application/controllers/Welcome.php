<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
        parent::__construct();
       // $this->get_user();
       $this->load->model('users_model');
	}
	public function index()
	{
		$this->load->view('welcome_message');
	}
	//send sms from to text
	public function sendSMS($to,$text)
	{
		$basic  = new \Nexmo\Client\Credentials\Basic('1721e9e5', 'kk1NoaqN5Dh0ir1q');
		$client = new \Nexmo\Client($basic);
		$insights = $client->insights()->standard($to);
		$message = $client->message()->send([
			'to' => $to,
			'from' => '18103206589',
			'text' => $text
		]);
		return $message;
	    
	}

	public function register()
	{
		//read registration data
		$org_data['Organization_name'] = $this->input->post('org_name');
		$org_data['Organization_address'] = $this->input->post('org_add');
		$org_data['Organization_unit'] = $this->input->post('org_unit');
		$org_data['Organization_city'] = $this->input->post('org_city');
		$org_data['Organization_state'] = $this->input->post('org_state');
		$org_data['Organization_country'] = $this->input->post('org_country');
		
		$emp_data['Employee_name'] = $this->input->post('emp_name');
		$emp_data['Employee_role'] = $this->input->post('emp_title');
		$emp_data['Employee_email'] = $this->input->post('emp_email');
		$emp_data['Employee_countrycode1'] = $this->input->post('emp_ccode1');
		$emp_data['Employee_cell1'] = $this->input->post('emp_cell1');
		$emp_data['Employee_countrycode2'] = $this->input->post('emp_ccode2');
		$emp_data['Employee_cell2'] = $this->input->post('emp_cell2');
		$emp_data['Employee_password'] = $this->input->post('emp_password');
		//check if  organization name already exists
		$org_name = array('Organization_name' => $org_data['Organization_name']);
		$result=$this->users_model->get_single('organizations',$org_name);
		//if exists
		if($result){
			// echo json_encode("organization already exists");
			$this->users_model->update_data('organizations',$org_data,$org_name);
			$org_id=$result->Organization_ID;
		}
		//if not exists
		else{
			$id=$this->users_model->get_max_id('organizations');
			if($id==0) $id=10000000;
			$org_id_num=$this->generateRandomNumber(10);
			$org_id_str=$this->generateRandomString(3);
			$org_id=$org_id_num.$org_id_str;
			$org_data['ID']=$id+1;
			$org_data['Organization_ID']=$org_id;
			
			$this->users_model->insert_data('organizations', $org_data);
		}
		//check if employee email exists
		$emp_email=array('Employee_email' => $emp_data['Employee_email']);
		$result=$this->users_model->get_single('users',$emp_email);
		//if exists
		if($result){
			$Verify_code = $this->generateRandomNumber(8);//make verify code
			$emp_data['Verify_code']=$Verify_code;
			$emp_data['Organization_ID']=$org_id;
			$this->users_model->update_data('users', $emp_data, $emp_email);
			// echo json_encode("employee already exists");
		}
		//if not exists
		else{
			$id=$this->users_model->get_max_id('users');
			if($id==0) $id=10000000;
			$emp_data['ID']=$id+1;
			$emp_data['Organization_ID']=$org_id;
			
			$Verify_code = $this->generateRandomNumber(8);//make verify code
			$emp_data['Verify_code']=$Verify_code;
			$this->users_model->insert_data('users', $emp_data);
		}
		
		// $message="success";
		$to=$emp_data['Employee_countrycode2'].$emp_data['Employee_cell2'];
		// $to="12403085501";
		$text=$emp_data['Verify_code'];
		$message=$this->sendSMS($to,$text);
		// $message="success";
		echo json_encode($message);
		// $this->load->view('welcome_message');
	}
	public function update(){
		
	}
	public function delete(){

	}
	public function get(){
		$emp_data=array('Employee_email'=>$this->input->post('emp_email'),'Employee_cell2'=>$this->input->post('emp_cell2'));
		$result=$this->users_model->get_single('users',$emp_data);
		echo json_encode($result->Verify_code);
	}
	public function matchcode()
	{
		$this->form_validation->set_rules('code', 'Code', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');

		if ($this->form_validation->run() == true)
        {
			$data1 = array('code' => $this->input->post('code'), 'email' => $this->input->post('email'));
			$get_data = $this->home_model->get_single('user_registration', $data1);
			if($get_data!=''){		
				$update_page = $this->home_model->update_data('user_registration',array('code' => ''), array('email' => $this->input->post('email')));
				echo "match";
			}else{
				echo "wrong";
			}
		}
	}
	public function generateRandomString($length = 3) {
		$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	public function generateRandomNumber($length = 10) {
		$characters = '1234567890';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
// end code vaib

}
