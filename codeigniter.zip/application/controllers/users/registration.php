<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registration extends CI_Controller {
    // controller for registration page
	public function index()
	{
		$this->load->view('users/registration1');
    }
    public function step($id){
        $url="users/registration{$id}";
        $this->load->view($url);
    }
}
