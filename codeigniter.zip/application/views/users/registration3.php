<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Registration page</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A premium admin dashboard template by Mannatthemes" name="description" />
        <meta content="Mannatthemes" name="author" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo base_url('assets/images/favicon.ico')?>">

        <!-- App css -->
        <link href="<?php echo base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url('assets/css/icons.css')?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url('assets/css/metisMenu.min.css')?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url('assets/css/style.css')?>" rel="stylesheet" type="text/css" />

    </head>

    <body class="account-body accountbg">

        <!-- Log In page -->
        <div class="row vh-100 ">
            <div class="col-12 align-self-center">
                <div class="auth-page">
                    <div class="card auth-card shadow-lg">
                        <div class="card-body">
                            <div class="px-3">
                                <div class="auth-logo-box">
                                    <a href="#" class="logo logo-admin"><img src="<?php echo base_url('images/registration_images/reg_image_three.png')?>" height="55" alt="logo" class="auth-logo"></a>
                                </div><!--end auth-logo-box-->
                                
                                <div class="text-center auth-logo-text">
                                    <h4 class="mt-0 mb-3 mt-5" style="color:red;">IMPORTANT</h4>
                                    <p class="text-muted mb-3">The login process will require that you enter your
                                        Email.Password every time you try to use the application.In addition, we will send 
                                        you a SMS with 8-digits code to verify that it is you.
                                    </p>  
                                    <p class="text-muted mb-3">Please provide the mobile(cell) number that you
                                        would like to associate with your account. This number must be able to receive
                                        text messages(SMS).
                                    </p>
                                </div> <!--end auth-logo-text-->  

                                
                                <form class="form-horizontal auth-form my-4" action="4">
                                    <div class="form-inline">
                                        <div class="form-group inline-l-30">
                                            <label for="countryCode">Country Code</label>
                                            <div class="input-group mb-3">
                                                <span class="auth-form-icon">
                                                    <!-- <i class="dripicons-mail"></i>  -->
                                                </span>                                                                                                              
                                                <input type="text" class="form-control" id="countryCode" placeholder="">
                                            </div>                                    
                                        </div><!--end form-group-->
                                        <div class="form-group inline-r-60">
                                            <label for="cell">Cell(Mobile) Number</label>
                                            <div class="input-group mb-3">
                                                <span class="auth-form-icon">
                                                    <!-- <i class="dripicons-mail"></i>  -->
                                                </span>                                                                                                              
                                                <input type="text" class="form-control" id="cell" placeholder="">
                                            </div>                                    
                                        </div><!--end form-group-->
                                    </div>
                                    <div class="form-group mb-0 row">
                                        <div class="col-6 mt-2 centering">
                                            <button class="btn btn-primary btn-round btn-block waves-effect waves-light" type="submit">Send SMS</button>
                                        </div><!--end col--> 
                                    </div> <!--end form-group-->  
                                    <div class="form-group mb-0 row">
                                        <div class="col-4 mt-2 centering">
                                            <button class="btn btn-primary btn-round btn-block waves-effect waves-light">Go Back</button>
                                        </div><!--end col--> 
                                    </div> <!--end form-group-->                           
                                </form><!--end form-->
                            </div><!--end /div-->
                        </div><!--end card-body-->
                    </div><!--end card-->
                </div><!--end auth-card-->
            </div><!--end col-->           
        </div><!--end row-->
        <!-- End Log In page -->

        <!-- jQuery  -->
        <script src="<?php echo base_url('assets/js/jquery.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/bootstrap.bundle.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/metisMenu.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/waves.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/jquery.slimscroll.min.js')?>"></script>

        <!-- App js -->
        <script src="<?php echo base_url('assets/js/app.js')?>"></script>

    </body>
</html>