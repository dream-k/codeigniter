<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Registration page</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A premium admin dashboard template by Mannatthemes" name="description" />
        <meta content="Mannatthemes" name="author" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo base_url('assets/images/favicon.ico')?>">

        <!-- App css -->
        <link href="<?php echo base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url('assets/css/icons.css')?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url('assets/css/metisMenu.min.css')?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url('assets/css/style.css')?>" rel="stylesheet" type="text/css" />

    </head>

    <body class="account-body accountbg">

        <!-- Log In page -->
        <div class="row vh-100 ">
            <div class="col-12 align-self-center">
                <div class="auth-page">
                    <div class="card auth-card shadow-lg">
                        <div class="card-body">
                            <div class="px-3">
                                <div class="auth-logo-box">
                                    <a href="#" class="logo logo-admin"><img src="<?php echo base_url('images/registration_images/reg_image_four.png')?>" height="55" alt="logo" class="auth-logo"></a>
                                </div><!--end auth-logo-box-->
                                
                                <div class="text-center auth-logo-text">
                                    <h4 class="mt-0 mb-3 mt-5">Enter Code</h4>
                                    <p class="text-muted mb-0">You should receive a text messages(SMS)
                                        shortly. Enter the code received below to verify
                                        this cell phone number provided.
                                    </p>  
                                </div> <!--end auth-logo-text-->  

                                
                                <form class="form-horizontal auth-form my-4" action="5">
                                    <div class="form-group">
                                        <div class="input-group mb-3 inline-r-45 centering">
                                            <!-- <span class="auth-form-icon">
                                                <i class="dripicons-user"></i> 
                                            </span>                                                                                                               -->
                                            <input type="text" class="form-control verifyCode" id="verifyCode" placeholder="00000000">
                                        </div>                                    
                                    </div><!--end form-group-->
                                    <div class="form-group">
                                        <p class="inline-r-30 verifyTimer">
                                            <span style="font-size:26px;">05:00</span><br>
                                            <span>minutes left</span>
                                        </p>                            
                                    </div><!--end form-group-->
                                    <div class="form-group mb-0 row">
                                        <div class="col-8 mt-2 centering">
                                            <button class="btn btn-primary btn-round btn-block waves-effect waves-light" type="submit">Complete!</button>
                                        </div><!--end col--> 
                                    </div> <!--end form-group-->    
                                    <div class="form-inline inline-margin">
                                        <div class="form-group inline-l-45">
                                            
                                                <button class="btn btn-primary btn-round btn-block waves-effect waves-light">Go Back</button>
                                            
                                        </div> <!--end form-group--> 
                                        <div class="form-group inline-r-45">
                                            
                                                <button class="btn btn-primary btn-round btn-block waves-effect waves-light">Resend</button>
                                            
                                        </div> <!--end form-group
                                    </div>                                       -->
                                </form><!--end form-->
                            </div><!--end /div-->
                        </div><!--end card-body-->
                    </div><!--end card-->
                </div><!--end auth-card-->
            </div><!--end col-->           
        </div><!--end row-->
        <!-- End Log In page -->

        <!-- jQuery  -->
        <script src="<?php echo base_url('assets/js/jquery.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/bootstrap.bundle.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/metisMenu.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/waves.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/jquery.slimscroll.min.js')?>"></script>

        <!-- App js -->
        <script src="<?php echo base_url('assets/js/app.js')?>"></script>

    </body>
</html>